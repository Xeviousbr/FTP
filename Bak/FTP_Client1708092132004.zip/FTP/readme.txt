FTP Client built on my FTP Class for .NET written in visual basic.NET if you use this control please just place my name in the credits for your program along with http://www.zen18657.zen.co.uk/ website

Andrew Duff